Types = new Mongo.Collection('types');
Attributes = new Mongo.Collection('attributes');
